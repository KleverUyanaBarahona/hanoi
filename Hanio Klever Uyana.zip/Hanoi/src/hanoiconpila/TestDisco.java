package hanoiconpila;

public class TestDisco {
	public static void main(String[] args) {
		
	 Disco disco1 =new Disco(1);
	disco1.comprobarMenor3(disco1.getDiametro());	
	disco1.comprobarPar(disco1.getDiametro());
	System.out.println(disco1.getDiametro());
	
	disco1.dibujar();
	System.out.println("");
	 Disco disco2 =new Disco(4);
		disco2.comprobarMenor3(disco2.getDiametro());	
		disco2.comprobarPar(disco2.getDiametro());
		System.out.println(disco2.getDiametro());
		
		disco2.dibujar();
	}
}
