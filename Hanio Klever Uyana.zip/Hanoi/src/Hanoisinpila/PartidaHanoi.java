package Hanoisinpila;

import java.util.ArrayList;

public class PartidaHanoi {
	private int nDiscos;
	private ArrayList<Poste> poste=new ArrayList<Poste>(3);
	
	public PartidaHanoi(int nDiscos){
		
	if (nDiscos==0){
			System.out.println("ERROR: La partida debe tener al menos un disco");
			nDiscos=1;
	}
		ArrayList<Disco> discos0=new ArrayList<Disco>();
		Poste poste0=new Poste(discos0);
		ArrayList<Disco> discos1=new ArrayList<Disco>();
		Poste poste1=new Poste(discos1);
		ArrayList<Disco> discos2=new ArrayList<Disco>();
		Poste poste2=new Poste(discos2);
			
		for(int i=(nDiscos);i>0;i--){
				int diametro=i*2+1;
				if (i%2==0){
					poste0.insertarDisco(new Disco (diametro));
				}
				else{
					poste0.insertarDisco(new DiscodePiedra(diametro));
				}
			
			this.poste.add(poste0);
			this.poste.add(poste1);
			this.poste.add(poste2);
			this.nDiscos=nDiscos;
		}
	}
	public boolean haTerminado(){
		if(this.poste.get(0).esVacio() && this.poste.get(1).esVacio()){
			return true;
		}
		else{
			return false;
		}
	}
	public void mover(int posteOrigen,int posteDestino){
		if(posteOrigen<0 || posteOrigen>2 || posteDestino<0 || posteDestino>2){
			System.out.println("n�mero de poste origen o destino inv�lido");
		}
		else{
			if(this.poste.get(posteOrigen).esVacio()){
				System.out.println("el poste "+posteOrigen+" esta vacio");
			}
			else{
				if (this.poste.get(posteDestino).esVacio()){
					moverDisco(posteOrigen,posteDestino);
				}
				else{
					if(this.poste.get(posteOrigen).obtenerDiametroDiscoCima()>this.poste.get(posteDestino).obtenerDiametroDiscoCima()){
						System.out.println("el disco de la torre "+posteOrigen+" tiene mayor diametro que el disco de la torre "+posteDestino);
					}
					else{
						moverDisco(posteOrigen,posteDestino);
					}
				}
			}
			
		}
	}
	
	private void moverDisco(int posteOrigen,int posteDestino) {
		this.poste.get(posteDestino).insertarDisco(this.poste.get(posteOrigen).extraerDisco());
		this.poste.get(posteOrigen).BorrarDisco();
	}
	public void dibujar(){
		for(int i=0;i<3;i++){
			System.out.println("Poste "+i+":");
			System.out.println();
			this.poste.get(i).dibujar();
			System.out.println();
		}
	}
	
}
