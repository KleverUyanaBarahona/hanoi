package Hanoisinpila;

public class TestDisco {

	public static void main(String[] args) {
		
		Disco disco1=new Disco(1);
		
		Disco disco4=new Disco(6);
		
		Disco disco7=new Disco(2);
		
		Disco disco3=new Disco(4);
		
		disco7.dibujarDisco();
		
		System.out.println(disco7.diametroDisco());
	}

}
