package Hanoisinpila;

public class Disco {
	private int diametro;
	
	public Disco(int diametro){
		if (diametro<3){
			this.diametro=3;
			System.out.println("ADVERTENCIA: di�metro demasiado peque�o, se le asigna un 3.");
		}
		else{
		if ((diametro%2)==0){
			this.diametro=diametro+1;
			System.out.println("ADVERTENCIA: di�metro del disco inv�lido, se le asigna un diametro de "+(diametro+1)+".");
		}
		else{
			this.diametro=diametro;
		}
		}
	}
	public int diametroDisco(){
		return this.diametro;
	}
	public void dibujarDisco(){
		String disco="";
		for(int i=0;i<this.diametro;i++){
			disco=disco+"O";
		}
		System.out.println(disco);
	}
	public void dibujarDisco(int numEspacios){
		String disco="";
		for(int i=0;i<numEspacios;i++){
			disco=disco+" ";
		}
		for(int c=0;c<this.diametro;c++){
			disco=disco+"O";
		}
		System.out.println(disco);
	}
}
