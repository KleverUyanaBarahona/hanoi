package Hanoisinpila;

import java.util.InputMismatchException;
import java.util.Scanner;

public class TestPartida {
		public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		int c;
		do{
			System.out.println("***********************");
			System.out.println("* LAS TORRES DE HANOI *");
			System.out.println("***********************");
			System.out.println();
			System.out.println("Men� principal:");
			System.out.println();
			System.out.println("1- Nueva partida");
			System.out.println();
			System.out.println("2- Salir del programa");
			System.out.println();
			System.out.print("Escoge una opci�n: ");
			try{
			c=sc.nextInt();
			}
			catch (InputMismatchException e){
				System.out.println("�Cuidado! Debes introducir un n�mero.");
				String basura = sc.next();
				c=0;
			}
			if (c==1){
				System.out.print("introduce el n�mero de discos de la partida: ");
				int ndisc;
				try{
				ndisc=sc.nextInt();
				
				}
				catch (InputMismatchException e){
					System.out.println("�Cuidado! Debes introducir un n�mero.");
					String basura = sc.next();
					ndisc=3;
				}
				
				PartidaHanoi partida=new PartidaHanoi(ndisc);
				System.out.println();
				partida.dibujar();
				int d;
				do{
					System.out.println("�Qu� deseas hacer?");
					System.out.println();
					System.out.println("1- Realizar un movimiento");
					System.out.println();
					System.out.println("2- Abandonar la partida");
					System.out.println();
					System.out.print("Escoge una opci�n: ");
					try{
						d=sc.nextInt();
						
					}
						catch (InputMismatchException e){
							System.out.println("�Cuidado! Debes introducir un n�mero.");
							String basura = sc.next();
							d=0;
						}
					
					if(d==1){
						System.out.print("N�mero de poste de origen (0-2): ");
						int posteOrigen;
						try{
						posteOrigen=sc.nextInt();
						}
						catch (InputMismatchException e){
							System.out.println("�Cuidado! Debes introducir un n�mero.");
							String basura = sc.next();
							posteOrigen=-1;
						}
						System.out.print("N�mero de poste de destino (0-2): ");
						int posteDestino;
						try{
							posteDestino=sc.nextInt();
							}
							catch (InputMismatchException e){
								System.out.println("�Cuidado! Debes introducir un n�mero.");
								String basura = sc.next();
								posteDestino=-1;
							}
						partida.mover(posteOrigen, posteDestino);
						System.out.println();
						partida.dibujar();
						System.out.println();
						if(partida.haTerminado()){
							System.out.println("�ENHORABUENA! �LO HAS CONSEGUIDO!");
							d=2;
						}
					}
				}while (d!=2);
			}
		}while (c!=2);
	}

}
