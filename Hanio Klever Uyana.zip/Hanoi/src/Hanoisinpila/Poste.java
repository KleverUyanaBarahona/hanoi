package Hanoisinpila;

import java.util.ArrayList;

public class Poste {
	private ArrayList<Disco> discos=new ArrayList<Disco>();
	public Poste(ArrayList<Disco> discos){
		this.discos=discos;
	}
	public boolean esVacio(){
		if(this.discos.size()==0){
			return true;
		}
		else{
			return false;
		}
	}
	public int obtenerDiametroDiscoCima(){
		if(this.discos.size()==0){
			return 0;
		}
		else{
			int i=this.discos.size()-1;
			return this.discos.get(i).diametroDisco();
		}
	}
	public void insertarDisco(Disco disco){
		this.discos.add(disco);
	}
	public Disco extraerDisco(){
		if (this.discos.size()==0){
			return null;
		}
		else{
			int i=this.discos.size()-1;
			return this.discos.get(i);
			
		}
	}
	public void BorrarDisco() {
		int i=this.discos.size()-1;
		this.discos.remove(this.discos.get(i));
	}
	public void dibujar(){
		if (this.discos.size()==0){
			String palo="";
			for(int i=0;i<5;i++){
				palo=palo+"=";
			}
			System.out.println(palo);
		}
		else{
		for(int i=(this.discos.size());i>0;i--){
			int numE=(this.discos.get(0).diametroDisco()+1)/2-(this.discos.get(i-1).diametroDisco()/2);
			this.discos.get(i-1).dibujarDisco(numE);
		}
		String palo="";
		for(int i=0;i<=(this.discos.get(0).diametroDisco()+1);i++){
			palo=palo+"=";
		}
		System.out.println(palo);
		}
		
	}
	
	
}
