package Hanoisinpila;

import java.util.ArrayList;

public class TestPoste {

	public static void main(String[] args) {
		
		ArrayList<Disco> discos1=new ArrayList<Disco>();
		
		ArrayList<Disco> discos2=new ArrayList<Disco>();
		
		ArrayList<Disco> discos3=new ArrayList<Disco>();
		Poste poste1=new Poste (discos1);
		
		Poste poste2=new Poste (discos2);
		
		Poste poste3=new Poste (discos3);
		
		System.out.println(poste1.esVacio());
		
		poste1.dibujar();
		
		System.out.println(poste1.obtenerDiametroDiscoCima());
		
		DiscodePiedra disco4=new DiscodePiedra(4);
		
		Disco disco7=new Disco(7);
		
		Disco disco3=new Disco(3);
		
		poste1.insertarDisco(disco7);
		
		poste1.insertarDisco(disco4);
		
		poste1.insertarDisco(disco3);
		
		System.out.println(poste1.esVacio());
		
		poste1.dibujar();
		
		System.out.println(poste1.obtenerDiametroDiscoCima());
		
		poste1.dibujar();
		
		poste2.dibujar();
		
		poste3.dibujar();
	}
	
}
